package com.feedback.pojo;

public class Inputfeedbackpojo {
	
	private String knowledge_of_subject;
	private String coming_well_for_class;
	private String giving_clear_explanations;
	private String command_of_language;
	private String clear_and_audible_voice;
	private String holding_attention_of_students;
	private String providing_more_matter;
	private String clear_the_doubts;
	private String encouraging_students;
	private String appreciating_students;
	private String willingness_to_help_students;
	private String return_of_testpapers;
	private String punctuality_following_timetable;
	private String coverage_of_syllabus;
	private String impartial;
	private String department;
	private String hod_name;
	private String faculty_name;
	private String subject_name;
	private String year;
	private String semester;
	private String acadamic_year;
	
	

	public String getAcadamic_year() {
		return acadamic_year;
	}
	public void setAcadamic_year(String acadamic_year) {
		this.acadamic_year = acadamic_year;
	}
	public String getKnowledge_of_subject() {
		return knowledge_of_subject;
	}
	public void setKnowledge_of_subject(String knowledge_of_subject) {
		this.knowledge_of_subject = knowledge_of_subject;
	}
	public String getComing_well_for_class() {
		return coming_well_for_class;
	}
	public void setComing_well_for_class(String coming_well_for_class) {
		this.coming_well_for_class = coming_well_for_class;
	}
	public String getGiving_clear_explanations() {
		return giving_clear_explanations;
	}
	public void setGiving_clear_explanations(String giving_clear_explanations) {
		this.giving_clear_explanations = giving_clear_explanations;
	}
	public String getCommand_of_language() {
		return command_of_language;
	}
	public void setCommand_of_language(String command_of_language) {
		this.command_of_language = command_of_language;
	}
	public String getClear_and_audible_voice() {
		return clear_and_audible_voice;
	}
	public void setClear_and_audible_voice(String clear_and_audible_voice) {
		this.clear_and_audible_voice = clear_and_audible_voice;
	}
	public String getHolding_attention_of_students() {
		return holding_attention_of_students;
	}
	public void setHolding_attention_of_students(String holding_attention_of_students) {
		this.holding_attention_of_students = holding_attention_of_students;
	}
	public String getProviding_more_matter() {
		return providing_more_matter;
	}
	public void setProviding_more_matter(String providing_more_matter) {
		this.providing_more_matter = providing_more_matter;
	}
	public String getClear_the_doubts() {
		return clear_the_doubts;
	}
	public void setClear_the_doubts(String clear_the_doubts) {
		this.clear_the_doubts = clear_the_doubts;
	}
	public String getEncouraging_students() {
		return encouraging_students;
	}
	public void setEncouraging_students(String encouraging_students) {
		this.encouraging_students = encouraging_students;
	}
	public String getAppreciating_students() {
		return appreciating_students;
	}
	public void setAppreciating_students(String appreciating_students) {
		this.appreciating_students = appreciating_students;
	}
	public String getWillingness_to_help_students() {
		return willingness_to_help_students;
	}
	public void setWillingness_to_help_students(String willingness_to_help_students) {
		this.willingness_to_help_students = willingness_to_help_students;
	}
	public String getReturn_of_testpapers() {
		return return_of_testpapers;
	}
	public void setReturn_of_testpapers(String return_of_testpapers) {
		this.return_of_testpapers = return_of_testpapers;
	}
	public String getPunctuality_following_timetable() {
		return punctuality_following_timetable;
	}
	public void setPunctuality_following_timetable(String punctuality_following_timetable) {
		this.punctuality_following_timetable = punctuality_following_timetable;
	}
	public String getCoverage_of_syllabus() {
		return coverage_of_syllabus;
	}
	public void setCoverage_of_syllabus(String coverage_of_syllabus) {
		this.coverage_of_syllabus = coverage_of_syllabus;
	}
	public String getImpartial() {
		return impartial;
	}
	public void setImpartial(String impartial) {
		this.impartial = impartial;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getHod_name() {
		return hod_name;
	}
	public void setHod_name(String hod_name) {
		this.hod_name = hod_name;
	}
	public String getFaculty_name() {
		return faculty_name;
	}
	public void setFaculty_name(String faculty_name) {
		this.faculty_name = faculty_name;
	}
	public String getSubject_name() {
		return subject_name;
	}
	public void setSubject_name(String subject_name) {
		this.subject_name = subject_name;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getSemester() {
		return semester;
	}
	public void setSemester(String semester) {
		this.semester = semester;
	}
	
	
}
